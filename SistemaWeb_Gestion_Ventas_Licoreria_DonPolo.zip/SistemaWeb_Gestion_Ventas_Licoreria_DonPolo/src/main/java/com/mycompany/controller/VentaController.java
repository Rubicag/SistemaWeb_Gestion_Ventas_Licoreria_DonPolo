package com.mycompany.controller;
public class VentaController {
    
}
