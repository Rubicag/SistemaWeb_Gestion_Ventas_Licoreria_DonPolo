package com.mycompany.model;

public class Producto {
    private int id_producto;
    private String nombre;
    private double precio;
    private int cantidad;
    private int id_categoria;
    private int id_proveedor;

    // Métodos setters
    public void setId_Producto(int id_producto) {
        this.id_producto = id_producto;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public void setId_Categoria(int id_categoria) {
        this.id_categoria = id_categoria;
    }

    public void setId_Proveedor(int id_proveedor) {
        this.id_proveedor = id_proveedor;
    }

    // Métodos getters (si es necesario)
    public int getId_Producto() {
        return id_producto;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public int getId_Categoria() {
        return id_categoria;
    }

    public int getId_Proveedor() {
        return id_proveedor;
    }
    // Método toString opcional para depuración
    @Override
    public String toString() {
        return "Producto{" +
               "id_producto=" + id_producto + 
                ", nombre='" + nombre + '\'' +
                ", precio=" + precio +
                ", cantidad=" + cantidad +
                "id_categoria=" + id_categoria +
                "id_proveedor=" + id_proveedor +
                '}';
    }
}
